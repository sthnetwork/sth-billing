<!-- Core JS -->
<script src="{{ asset('assets/vendors/core/core.js') }}"></script>

<!-- Plugin JS -->
<script src="{{ asset('assets/vendors/flatpickr/flatpickr.min.js') }}"></script>
<script src="{{ asset('assets/vendors/apexcharts/apexcharts.min.js') }}"></script>

<!-- Template JS -->
<script src="{{ asset('assets/js/app.js') }}"></script>

<!-- Custom Dashboard JS -->
<script src="{{ asset('assets/js/dashboard.js') }}"></script>
